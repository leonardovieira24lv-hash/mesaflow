import { Inbox } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { getRecentOrders } from "@/lib/dashboard/queries";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { AdminOrderStatusBadge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";
import { SectionError } from "@/components/dashboard/section-error";
import { formatCurrency } from "@/lib/format";

const timeFormatter = new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit" });

/**
 * Últimos pedidos — consulta real (`lib/dashboard/queries.ts`).
 *
 * Nota (Sprint 10, auditoria de qualidade): o comentário original desta
 * função dizia que a lista "sempre mostra o estado vazio, porque a Área do
 * Cliente ainda não existe" — isso descrevia o estado da Sprint 5 e ficou
 * desatualizado assim que a Sprint 8 implementou a criação de pedidos
 * (contrato 3.3). `getRecentOrders` já consulta a tabela `orders` de verdade
 * e não precisou de nenhuma mudança para isso — só a documentação estava
 * errada, corrigida aqui.
 *
 * Sprint 2 (Painel Vivo): este componente continua um Server Component sem
 * nenhuma assinatura própria — quem mantém a lista atual é
 * `<DashboardRealtimeSync>` (`page.tsx`), chamando `router.refresh()` a
 * cada mudança em `orders`, o que reexecuta esta consulta no servidor.
 */
export async function RecentOrders({ restaurantId }: { restaurantId: string }) {
  try {
    const supabase = await createClient();
    const orders = await getRecentOrders(supabase, restaurantId);

    return (
      <Card>
        <CardHeader>
          <CardTitle>Últimos pedidos</CardTitle>
          <CardDescription>Atualiza sozinha assim que um pedido é criado ou muda de status.</CardDescription>
        </CardHeader>
        <CardContent>
          {orders.length === 0 ? (
            <EmptyState
              icon={Inbox}
              title="Nenhum pedido ainda"
              description="Assim que um cliente pedir pela mesa, ele aparece aqui."
            />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Mesa</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Horário</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-numeric">{order.tableName}</TableCell>
                    <TableCell>
                      <AdminOrderStatusBadge status={order.status} />
                    </TableCell>
                    <TableCell className="font-numeric">{formatCurrency(order.totalAmount)}</TableCell>
                    <TableCell className="font-numeric text-ds2-foreground-muted">
                      {timeFormatter.format(new Date(order.createdAt))}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    );
  } catch {
    return <SectionError message="Não foi possível carregar os pedidos agora." />;
  }
}
