import type { LucideIcon } from "lucide-react";
import type { Route } from "next";
import { UtensilsCrossed, LayoutGrid, QrCode, ArrowUpRight } from "lucide-react";
import { Card } from "@/components/ui/card";
import Link from "next/link";
import { ROUTES } from "@/constants/routes";

interface QuickAction {
  label: string;
  // `Route`, não `string`: com `typedRoutes` (next.config.mjs), `<Link href>`
  // exige uma rota conhecida em tempo de compilação. Declarar este campo como
  // `string` widening o literal de `ROUTES.*` (que é `as const`) de volta
  // para `string` genérico, e o build falha em "Type 'string' is not
  // assignable to type '...Route...'".
  href: Route;
  icon: LucideIcon;
}

const ACTIONS: QuickAction[] = [
  { label: "Cardápio", href: ROUTES.cardapioCategorias, icon: UtensilsCrossed },
  { label: "Mesas", href: ROUTES.mesas, icon: LayoutGrid },
  // QR Codes são gerenciados dentro da tela de Mesas (mesmo módulo, seção 7
  // do contrato) — sem tela própria ainda, por isso aponta para a mesma rota.
  { label: "QR Codes", href: ROUTES.mesas, icon: QrCode },
];

/**
 * Atalhos para os módulos de negócio do painel.
 *
 * Sprint "Refatoração da Experiência do Cardápio" (2026-07-28): existia um
 * atalho "Categorias" e outro "Produtos" — desde essa sprint as duas telas
 * viraram uma só (`/cardapio/categorias`, com `/cardapio/produtos` como
 * redirect pra lá), então os dois atalhos levavam exatamente ao mesmo
 * lugar. Consolidados num único atalho "Cardápio" (Sprint "Correção de
 * Responsividade do Dashboard", 2026-07-28, seguinte).
 */
export function QuickActions() {
  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-3">
      {ACTIONS.map(({ label, href, icon: Icon }) => (
        <Link key={label} href={href} className="group">
          <Card interactive className="flex items-center gap-3 p-5">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-ds2-sm bg-ds2-primary/10 transition-transform group-hover:scale-110">
              <Icon className="h-5 w-5 text-ds2-primary" aria-hidden />
            </div>
            <span className="flex-1 text-sm font-medium text-ds2-foreground">{label}</span>
            <ArrowUpRight
              className="h-4 w-4 shrink-0 text-ds2-foreground-muted opacity-0 transition-opacity group-hover:opacity-100"
              aria-hidden
            />
          </Card>
        </Link>
      ))}
    </div>
  );
}
