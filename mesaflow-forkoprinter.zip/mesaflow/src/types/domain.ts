/**
 * Tipos de domínio compartilhados entre front-end e Route Handlers.
 * Espelham as entidades descritas em `api-contracts-v1.md`.
 *
 * Quando o schema do Supabase for gerado (`npm run supabase:types`), os tipos
 * de banco (snake_case, vindos de `database.types.ts`) devem ser mapeados para
 * estes tipos de domínio (camelCase/contrato) na borda da API — nunca vazar o
 * tipo bruto do Postgres direto para o front-end.
 */

export type RestaurantStatus = "onboarding" | "active";

export interface Restaurant {
  id: string;
  name: string;
  slug: string;
  status: RestaurantStatus;
}

export interface RestaurantChecklist {
  hasCategories: boolean;
  hasProducts: boolean;
  qrCodesPrinted: boolean;
}

export type TableStatus = "livre" | "ocupada" | "manutencao";

export interface Table {
  id: string;
  name: string;
  status: TableStatus;
  qrToken: string;
}

export interface MenuCategory {
  id: string;
  name: string;
  position: number;
  // Sistema de Opcionais, Fase 3 — meio a meio (2026-08-14).
  allowsHalfAndHalf: boolean;
  // Layout compacto por categoria (2026-08-15).
  isCompact: boolean;
  // Foto de categoria (2026-08-15) — opcional, `null` quando não subida.
  imageUrl: string | null;
}

export interface MenuItem {
  id: string;
  categoryId: string;
  name: string;
  description?: string;
  price: number;
  imageUrl?: string;
  isAvailable: boolean;
  /** Sprint "Exclusão Lógica de Produtos": produto arquivado (tinha histórico de pedidos ao ser "excluído") — some do cardápio público e de novos pedidos, mas o registro e o histórico continuam intactos. */
  isArchived: boolean;
}

export type OrderStatus = "pending" | "preparing" | "ready" | "delivered" | "cancelled";

export interface OrderItem {
  id: string;
  menuItemId: string;
  name: string;
  quantity: number;
  notes?: string;
}

export interface Order {
  id: string;
  table: Pick<Table, "id" | "name">;
  status: OrderStatus;
  totalAmount: number;
  notes?: string;
  items: OrderItem[];
  createdAt: string;
}

/**
 * Versão resumida de `Order` para telas de listagem (Dashboard, Pedidos em
 * Tempo Real) — troca `items` completos por só a contagem, evitando um
 * payload pesado quando o detalhe não é necessário (contrato seção 8.1:
 * "resumo de itens", não os itens completos, que ficam para 8.2).
 */
export interface OrderListItem {
  id: string;
  table: Pick<Table, "id" | "name">;
  status: OrderStatus;
  totalAmount: number;
  itemCount: number;
  createdAt: string;
}

/** Papéis de usuário previstos no contrato (v1: só `owner`; `staff` chega na v1.1). */
export type UserRole = "owner" | "staff";

export interface Profile {
  id: string;
  restaurantId: string;
  role: UserRole;
}

// ── Eventos de mesa (Chamar garçom / Solicitar conta) ───────────────────────
// Ver docs/table-events-roadmap.md e supabase/migrations/0012_table_events.sql.
// Evento pontual que se resolve — não é um estado permanente da mesa.

export type TableEventType = "waiter_call" | "bill_request";
export type TableEventStatus = "open" | "acknowledged" | "resolved";

export interface TableEvent {
  id: string;
  table: Pick<Table, "id" | "name">;
  type: TableEventType;
  status: TableEventStatus;
  createdAt: string;
}
